// Accessing Mongoose package
const mongoose = require('mongoose');

// Database connection
mongoose.connect('mongodb://localhost:27017/library'); //,{useunifiedTopology:true,useNewUrlParser:true}

// Schema definition
const Schema = mongoose.Schema;

const AuthorSchema = new Schema({
    author: String,
    title: String,
    genre: String,
    image:String
});


// model creation
var Authordata = mongoose.model('authordata',AuthorSchema);
module.exports = Authordata;
