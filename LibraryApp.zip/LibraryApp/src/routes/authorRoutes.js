const express = require('express');
const authorsRouter = express.Router();
const Authordata = require('../model/Authordata');

function router(nav){
    // var authors=[
    //         {
    //             author:'Arthur Conan Doyle',
    //             title:'Stories of Sherlock Holmes',
    //             genre: 'Detective fiction',
    //             image: "ArthurConanDoyle.jpg"
    //         },
    //         {
    //             author:'Lalithambika Antharjanam',
    //             title:'Agnisakshi',
    //             genre: 'Novel',
    //             image: "Lalithambika.jpg"
    //         },
    //         {
                        
    //             author:'Ruskin Bond',
    //             title:'Delhi is not far',
    //             genre: 'Novel',
    //             image: "ruskin bond.jpg"
    //         }
    //     ]
    authorsRouter.get('/',function(req,res){        
        Authordata.find()
        .then(function(authors){
                res.render("authors",{
                nav,                 
                title:'Library ',
                authors
            });
        });
    });
            
    
    authorsRouter.get('/:id',function(req,res){
        const id = req.params.id
        Authordata.findOne({_id:id})
        .then(function(author){
        res.render("author",{
            nav,
                title:'Library',
                author            
            });
        });
    });
    authorsRouter.get('/:id/update', function(req, res){
        
        const id = req.params.id;
        Authordata.findOne({_id:id})
        .then(function(author){
            res.render("author",
        {
            nav,
            title:'Library',
            author
        });
        })
        
    });

    authorsRouter.post('/:id/update/upload', function(req, res){
        const id = req.params.id;
        var item={
           name :req.body.name,
            book : req.body.book,
            genre :req.body.genre,
            image : req.body.image

        };
        var author = Authordata(item);
             Authordata.findByIdAndUpdate({_id:id},req.body,{new:true})
        .then(function(author){
            res.redirect('/authors');
        });
    });


    authorsRouter.get('/:id/delete',function(req,res){
        const id = req.params.id;
        Authordata.findByIdAndDelete({_id:id})
        .then(function(author){
            res.redirect('/authors');
        });
    });


   
    return authorsRouter;
}


module.exports = router;
        