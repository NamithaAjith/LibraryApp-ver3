const express = require('express');
const booksRouter = express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav){
    // var books=[
    //     {
    //         title:'The Lord of the Rings',
    //         author:'J. R. R. Tolkien',
    //         genre: 'Fantasy & Adventure',
    //         image: "TheLordoftheRings.jpg"
    //     },
    //     {
    //         title:'The Alchemist',
    //         author:'Paulo Coelho',
    //         genre: 'Novel',
    //         image: "alchemist.jpg"
    //     },
    //     {
    //         title:'Stay Hungry Stay Foolish',
    //         author:'Rashmi Bansal',
    //         genre: 'Inspirational Non-fiction',
    //         image: "stayhungrystayfoolish.jpg"
    //     }
    // ]
    booksRouter.get('/',function(req,res){
        Bookdata.find()
        .then(function(books){
            res.render("books",{
                nav,                 
                title:'Library ',
                books
            });
        });
            
    });
    booksRouter.get('/:id',function(req,res){
        const id = req.params.id
        Bookdata.findOne({_id:id})
        .then(function(book){
        res.render("book",{
            nav,
                title:'Library',
                book
            });
        });
    }); 
    booksRouter.get('/:id/update', function(req, res){
        
        const id = req.params.id;
        Bookdata.findOne({_id:id})
        .then(function(book){
            res.render("book",
        {
            nav,
            title:'Library',
            book
        });
        })
        
    });

    
    booksRouter.post('/:id/update/upload', function(req, res){
        const id = req.params.id;
        var item={
           title :req.body.title,
            author : req.body.author,
            genre :req.body.genre,
            image : req.body.image

        };
        var img = req.body.image;
        if((req.body.image)==null){
            img = req.body.image;
        }
        var book = Bookdata(item);
        Bookdata.findByIdAndUpdate({_id:id},req.body,{new:true},)
        .then(function(book){
            res.redirect('/books');
        });
    });

   
   booksRouter.get('/:id/delete',function(req,res){
        const id = req.params.id;
        Bookdata.findByIdAndDelete({_id:id})
        .then(function(book){
            res.redirect('/books');
        });
    });

    return booksRouter;
}


module.exports = router;
        