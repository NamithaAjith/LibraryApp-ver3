const express = require('express');

const app = express();
const nav= [
        
        
        {link:'/books',name:'BOOKS'},
        {link:'/authors',name:'AUTHORS'},
        {link:'/admin' , name:'ADD BOOK'} ,
        {link:'/authadmin' , name:'ADD AUTHOR'} ,


];

const booksRouter = require('./src/routes/bookRoutes')(nav);
const authorsRouter = require('./src/routes/authorRoutes')(nav);
const adminRouter = require('./src/routes/adminRoutes')(nav);
const authadminRouter = require('./src/routes/authadminRoutes')(nav);



app.use(express.urlencoded({extended:true}));
app.use(express.static('./public'))
app.set('view engine' , 'ejs');
app.set('views','./src/views');
app.use('/books',booksRouter);
app.use('/authors',authorsRouter)
app.use('/admin',adminRouter);
app.use('/authadmin',authadminRouter);

// app.use('/public', express.static(path.join(__dirname, 'public')));

// var staticResource='C:/Users/ACER/Desktop/the road.jfif';
// app.use('/public2', express.static(path.join(staticResource, 'public2')));


app.get('/',function(req,res){
        res.render("index",
        {          
                nav,            
                title:'Library '
        }); 
});

app.listen(3400);